module.exports = {
  root: true,
  extends: ["shopware"],
};
