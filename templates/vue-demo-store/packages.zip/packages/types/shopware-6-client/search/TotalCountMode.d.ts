export type TotalCountMode = {
  /**
   * values exact, next_pages, none (default)
   */
  mode?: string;
};
