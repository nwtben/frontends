export type StoreSort = {
  field: string;
  order: string;
  naturalSorting?: boolean;
};
