/**
 * @public
 */
export type Grouping = {
  field: string;
};
