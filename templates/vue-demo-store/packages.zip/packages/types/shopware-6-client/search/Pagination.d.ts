/**
 * @public
 */
export type Pagination = {
  limit?: number;
  page?: number;
};
