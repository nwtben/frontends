/**
 * Interface that is being used for just a few fields in Shopware models. It contains elements[] only.
 */
/**
 * @public
 */
export type Collection = {
  elements: [];
};
