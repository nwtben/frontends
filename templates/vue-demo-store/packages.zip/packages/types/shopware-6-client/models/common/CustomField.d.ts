export type CustomFields = {
  [key: string]: boolean | string | number | Date;
};

/**
 * @public
 */
export type CustomField = unknown;
