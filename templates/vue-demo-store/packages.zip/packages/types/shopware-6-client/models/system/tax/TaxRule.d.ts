export type TaxRule = {
  taxRate: number;
  percentage: number;
};
