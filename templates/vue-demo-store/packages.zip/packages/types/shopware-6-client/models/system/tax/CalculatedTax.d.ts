export type CalculatedTax = {
  tax: number;
  taxRate: number;
  price: number;
};
