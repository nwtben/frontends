export type ListingPrice = {
  from: unknown;
  to: unknown;
  extensions: any[];
};
