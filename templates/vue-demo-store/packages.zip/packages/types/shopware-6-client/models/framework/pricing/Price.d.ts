export type Price = {
  currencyId: number;
  net: number;
  gross: number;
  linked: boolean;
};
