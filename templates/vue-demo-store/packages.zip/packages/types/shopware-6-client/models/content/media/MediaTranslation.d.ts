export type MediaTranslation = {
  name: string;
  alt: string;
  position: number;
  customFields: any;
};
