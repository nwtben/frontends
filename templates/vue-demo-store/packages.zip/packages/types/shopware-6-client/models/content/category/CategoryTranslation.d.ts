export type CategoryTranslation = unknown;
