export type MailTemplateMedia = unknown;
