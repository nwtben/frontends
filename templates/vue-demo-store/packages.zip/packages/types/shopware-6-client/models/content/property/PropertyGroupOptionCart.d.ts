/**
 * @public
 */
export type PropertyGroupOptionCart = {
  group: string;
  option: string;
};
