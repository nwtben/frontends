export type MediaFolder = unknown;
