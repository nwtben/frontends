export type MediaType = unknown;
