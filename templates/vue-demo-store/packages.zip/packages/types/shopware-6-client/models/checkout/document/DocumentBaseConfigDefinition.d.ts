export type DocumentBaseConfigDefinition = unknown;
