export type OrderDeliveryPosition = unknown;
