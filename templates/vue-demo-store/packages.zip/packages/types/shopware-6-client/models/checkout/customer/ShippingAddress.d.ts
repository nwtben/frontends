import { CustomerAddress } from "./CustomerAddress";

/**
 * @public
 */
export type ShippingAddress = CustomerAddress;
