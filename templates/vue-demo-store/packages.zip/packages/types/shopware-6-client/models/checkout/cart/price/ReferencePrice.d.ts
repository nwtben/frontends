export type ReferencePrice = {
  price: number;
  referenceUnit: string;
  unitName: string;
};
