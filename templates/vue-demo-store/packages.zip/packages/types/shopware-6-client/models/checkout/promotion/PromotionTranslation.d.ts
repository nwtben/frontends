export type PromotionTranslation = {
  promotionId: string;
  name: string | null;
};
