export type DocumentBaseConfig = unknown;
