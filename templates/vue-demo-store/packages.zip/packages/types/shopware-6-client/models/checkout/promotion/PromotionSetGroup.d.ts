export type PromotionSetGroup = unknown;
