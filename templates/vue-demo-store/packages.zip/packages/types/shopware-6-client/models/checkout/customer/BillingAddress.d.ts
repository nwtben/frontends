import { CustomerAddress } from "./CustomerAddress";

/**
 * @public
 */
export type BillingAddress = CustomerAddress;
