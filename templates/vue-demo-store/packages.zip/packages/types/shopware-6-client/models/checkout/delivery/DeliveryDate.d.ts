export type DeliveryDate = {
  readonly earliest: Date;
  readonly latest: Date;
};
