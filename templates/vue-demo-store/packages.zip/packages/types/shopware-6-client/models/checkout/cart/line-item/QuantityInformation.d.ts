export type QuantityInformation = {
  minPurchase: number;
  maxPurchase: number | null;
  purchaseSteps: number | null;
};
