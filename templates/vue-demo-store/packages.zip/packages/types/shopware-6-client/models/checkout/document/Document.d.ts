export type Document = unknown;
